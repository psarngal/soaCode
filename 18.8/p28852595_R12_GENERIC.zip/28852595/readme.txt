------------------------------------------------------------------------------------------------------------------------------------
OIHAB
------------------------------------------------------------------------------------------------------------------------------------
 
Step 1: Please retire the composite version MISIMDOMNotifySPM [6.6] from Critical domain, Default partition.
Step 2: Please deploy the attached jar file sca_MISIMDOMNotifySPM.jar to Critical domain, Default partition. Please use 'MISIMDOMNotifySPM_cfgplan_OIHAB.xml' as the configuration file for the deployment.


------------------------------------------------------------------------------------------------------------------------------------
OIHAT
------------------------------------------------------------------------------------------------------------------------------------

Step 1: Please retire the composite version MISIMDOMNotifySPM [6.8] from Critical domain, Default partition.
Step 2: Please deploy the attached jar file sca_MISIMDOMNotifySPM.jar to Critical domain, Default partition and set as default. Please use 
'MISIMDOMNotifySPM_cfgplan_OIHAT.xml' as the the configuration file for the deployment.

------------------------------------------------------------------------------------------------------------------------------------
OIHAV
------------------------------------------------------------------------------------------------------------------------------------

Step 1: Please retire the composite version MISIMDOMNotifySPM [6.8] from Critical domain, Default partition.
Step 2: Please deploy the attached jar file sca_MISIMDOMNotifySPM.jar to Critical domain, Default partition and set as default. Please use 
'MISIMDOMNotifySPM_cfgplan_OIHAV.xml' as the the configuration file for the deployment.

------------------------------------------------------------------------------------------------------------------------------------
OIHAU
------------------------------------------------------------------------------------------------------------------------------------

Step 1: Please retire the composite version MISIMDOMNotifySPM [6.3] from Critical domain, Default partition.
Step 2: Please deploy the attached jar file sca_MISIMDOMNotifySPM.jar to Critical domain, Default partition and set as default. Please use 
'MISIMDOMNotifySPM_cfgplan_OIHAU.xml' as the the configuration file for the deployment.

------------------------------------------------------------------------------------------------------------------------------------
OIHAS
------------------------------------------------------------------------------------------------------------------------------------
Step 1: Please retire the composite version MISIMDOMNotifySPM [6.7] from Critical domain, Default partition.
Step 2: Please deploy the attached jar file sca_MISIMDOMNotifySPM.jar to Critical domain, Default partition. Please use 
'MISIMDOMNotifySPM_cfgplan_OIHAS.xml' as the the configuration file for the deployment.

------------------------------------------------------------------------------------------------------------------------------------
OIHAP
------------------------------------------------------------------------------------------------------------------------------------
Step 1: Please retire the composite version MISIMDOMNotifySPM [6.7] from Critical domain, Default partition.
Step 2: Please deploy the attached jar file sca_MISIMDOMNotifySPM.jar to Critical domain, Default partition. Please use 
'MISIMDOMNotifySPM_cfgplan_OIHAP.xml' as the the configuration file for the deployment.


------------------------------------------------------------------------------------------------------------------------------------